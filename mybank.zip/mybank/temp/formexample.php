<!DOCTYPE html>
<html>
<head>
	<title>form example</title>
</head>
<body>
     <form action="server.php" method="POST">
          <h1>Input type test</h1>
          <input type="text" placeholder="Name">
          <input type="text" placeholder="this is disabled" disabled>
          <input type="text" placeholder="readonly" readonly>
          <input type="text" placeholder="this is required" required>
          <input type="password" placeholder="password">
          <h2>select tag</h2>
          <select>
               <option value="null" disabled selected>choose your favourite character</option>
               <option value="Goku">Goku</option>
               <option value="piccolo">piccolo</option>
               <option value="hit">hit</option>
               <option value="gohan">gohan</option>
               <option value="beerus">beerus</option>
          </select>
          <input type="radio" value="male" name="gender">Male
          <input type="radio" value="Female" name="gender">Female<br>
          <input type="checkbox" value="python" name="language[]">python<br>
          <input type="checkbox" value="java" name="language[]">java<br>
          <input type="checkbox" value="c" name="language[]">c<br>
          <input type="checkbox" value="html" name="language[]">html<br>
          <input type="checkbox" value="c#" name="language[]">c#<br>
          <input type="submit" value="submit">

     </form>


</body>
</html>