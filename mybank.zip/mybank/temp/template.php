<!DOCTYPE html>
<html>
<head>
	<title>template</title>
	<!--Bootstrap CDN -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<meta name="description" content="website description">
	<meta name="keywords" content="xyz,abc,123">
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- cdn end -->
<!-- icon -->
<link rel="icon" type="path" href="img/logo.png">
<!-- icon end -->
	
</head>
<body>
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-6 col-sm-offset-2" style="background-color: lavender;">.col-sm-6</div>
		<div class="row">
			<div class="col-sm-3 col-sm-offset-6" style="background-color: lavenderblush;">.col-sm-3</div>
		<div class="row">
			<div class="col-sm-1 col-sm-offset-4" style="background-color: lavender;">.col-sm-1</div>
	</div>
	<div class="row">
		<div class="col-sm-6" style="background-color:blue;">ddds</div>
	</div>
	</div>

</body>
</html>