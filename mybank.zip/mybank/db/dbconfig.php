<?php
	$host="localhost";
	$user="root";
	$pass="";
	$conn=mysql_connect($host,$user,$pass);
	mysql_select_db("payu");
	/*if($conn)
	{
	echo "connected";
	}
	else
	{
	echo "not connected";
	}*/
?>