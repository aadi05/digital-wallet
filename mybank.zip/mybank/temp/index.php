<!DOCTYPE html>
<html>
<head>
     <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<title>css</title>
     <link rel="stylesheet" type="text/css" href="my.css">
     <style type="text/css">
     h1{color:cyan;

     }
     li{color:blue;font-size:25px}

     </style>
</head>
<body>
     <h1>Introduction</h1>
     <h3>external css</h3>
     <ol type="A">
     	<li>Apple</li>
     	<li>samsung</li>
     	<li>oneplus</li>
     </ol>	
     <ul type="circle">
     	<li>Apple</li>
     	<li>samsung
     		<ol>
     			<li style="color:black">s8</li>
     		</ol>
     	</li>
     	<li>oneplus</li>
     </ul>
     <img src="img/Penguins.jpg">


</body>
</html>